//Group 4
import java.util.ArrayList;
import java.util.HashMap;
public class Chain {
	public static ArrayList<Block> blockchain = new ArrayList<Block>(); 
	static int difficulty = 2;
	public static float minimumTransaction = 0.1f;
	public static HashMap<String, TransactionOut> unTransOut = new HashMap<String, TransactionOut>();
	public static Wallet test1;
	public static Wallet test2;
	
	public static void main(String[]args) {


		blockchain.add(new Block("This is the gen block", "0"));	
		System.out.println("mining block one");
		blockchain.get(0).mineBlock(difficulty);

		blockchain.add(new Block("This is the second block",blockchain.get(blockchain.size()-1).hash)); 
		System.out.println("mining block two");
		blockchain.get(1).mineBlock(difficulty);

		blockchain.add(new Block("This is the third block",blockchain.get(blockchain.size()-1).hash));
		System.out.println("mining block three");
		blockchain.get(2).mineBlock(difficulty);
System.out.println("\n  \n");

printChain();

	}
	public static void printChain() {
		int i=0;
		boolean running = true;

		while(running == true) {
			System.out.println("Block#: "+ i+ " "+ blockchain.get(i));
			i++;
			if(i==blockchain.size()) running=false;
		}

	}


	public static Boolean chainValidityCheck () {
		Block cB; 
		Block pB;

		int i = 1;
		while (i < blockchain.size()) {
			cB = blockchain.get(i);
			pB = blockchain.get(i-1);
			if(!cB.hash.equals(cB.calculateHash()) ){
				System.out.println("The Current Hashes are not equal");			
				return false;
			}
			if(!pB.hash.equals(cB.previousHash) ) {
				System.out.println("The previous Hashes are not equal");
				return false;
			}
			i++;
		}
		return true;
	}
}

